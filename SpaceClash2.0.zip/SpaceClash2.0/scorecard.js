// scorecard.js
// Modular score card image generator for Space Clash 2.0

/**
 * Generates a stylized score card image and triggers download or sharing.
 * @param {Object} opts - Options for the score card
 * @param {string} opts.name - Player name
 * @param {number} opts.score - Player score
 * @param {number} opts.level - Player level
 * @param {number} [opts.accuracy] - Player accuracy as a percentage (0-100)
 */
function generateScoreCardImage({ name = 'PLAYER', score = 0, level = 1, accuracy = null }) {
    // Create off-screen canvas
    const width = 600;
    const height = 340;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = '#1b2735';
    ctx.fillRect(0, 0, width, height);
    // Neon border
    ctx.strokeStyle = '#00fff7';
    ctx.lineWidth = 8;
    ctx.shadowColor = '#00fff7';
    ctx.shadowBlur = 16;
    ctx.strokeRect(8, 8, width - 16, height - 16);
    ctx.shadowBlur = 0;

    // Game title
    ctx.font = 'bold 38px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText('Space Clash 2.0', width / 2, 32);

    // Player name
    ctx.font = 'bold 28px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#ffd700';
    ctx.fillText(name, width / 2, 90);

    // Score
    ctx.font = 'bold 54px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#00fff7';
    ctx.fillText(`Score: ${score}`, width / 2, 150);

    // Level
    ctx.font = 'bold 32px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#ff00ff';
    ctx.fillText(`Level: ${level}`, width / 2, 220);

    // Accuracy (if provided)
    if (accuracy !== null && !isNaN(accuracy)) {
        ctx.font = 'bold 28px Orbitron, Arial, sans-serif';
        ctx.fillStyle = '#ffd700';
        ctx.fillText(`Accuracy: ${Math.round(accuracy)}%`, width / 2, 255);
    }

    // Footer
    ctx.font = '20px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#fff';
    ctx.fillText('Can you beat my score?', width / 2, 280);

    // Convert to image and provide download/share options
    canvas.toBlob(blob => {
        const url = URL.createObjectURL(blob);
        // Create a modal overlay for download/share
        let modal = document.getElementById('scoreCardModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'scoreCardModal';
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.width = '100vw';
            modal.style.height = '100vh';
            modal.style.background = 'rgba(0,0,0,0.85)';
            modal.style.display = 'flex';
            modal.style.flexDirection = 'column';
            modal.style.justifyContent = 'center';
            modal.style.alignItems = 'center';
            modal.style.zIndex = '9999';
            document.body.appendChild(modal);
        }
        modal.innerHTML = '';
        // Show the image preview
        const img = document.createElement('img');
        img.src = url;
        img.alt = 'Score Card';
        img.style.maxWidth = '90vw';
        img.style.maxHeight = '60vh';
        img.style.borderRadius = '18px';
        img.style.boxShadow = '0 0 32px #00fff7, 0 0 8px #ffd700 inset';
        img.style.marginBottom = '32px';
        modal.appendChild(img);
        // Download button
        const downloadBtn = document.createElement('button');
        downloadBtn.textContent = 'Download Image';
        downloadBtn.style.padding = '12px 32px';
        downloadBtn.style.fontSize = '20px';
        downloadBtn.style.background = '#ffd700';
        downloadBtn.style.color = '#222';
        downloadBtn.style.border = 'none';
        downloadBtn.style.borderRadius = '50px';
        downloadBtn.style.margin = '0 12px 0 0';
        downloadBtn.style.cursor = 'pointer';
        downloadBtn.onclick = () => {
            const a = document.createElement('a');
            a.href = url;
            a.download = `spaceclash2-score.png`;
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => {
                document.body.removeChild(a);
            }, 100);
        };
        modal.appendChild(downloadBtn);
        // Share button (if supported)
        if (navigator.canShare && navigator.canShare({ files: [new File([blob], 'spaceclash2-score.png', { type: 'image/png' })] })) {
            const shareBtn = document.createElement('button');
            shareBtn.textContent = 'Share Image';
            shareBtn.style.padding = '12px 32px';
            shareBtn.style.fontSize = '20px';
            shareBtn.style.background = '#00fff7';
            shareBtn.style.color = '#222';
            shareBtn.style.border = 'none';
            shareBtn.style.borderRadius = '50px';
            shareBtn.style.margin = '0 0 0 12px';
            shareBtn.style.cursor = 'pointer';
            shareBtn.onclick = async () => {
                try {
                    await navigator.share({
                        files: [new File([blob], 'spaceclash2-score.png', { type: 'image/png' })],
                        title: 'Space Clash 2.0 Score',
                        text: `Check out my score in Space Clash 2.0!`
                    });
                } catch (e) {
                    alert('Sharing failed or was cancelled.');
                }
            };
            modal.appendChild(shareBtn);
        }
        // Close button
        const closeBtn = document.createElement('button');
        closeBtn.textContent = 'Close';
        closeBtn.style.padding = '10px 28px';
        closeBtn.style.fontSize = '18px';
        closeBtn.style.background = '#222';
        closeBtn.style.color = '#fff';
        closeBtn.style.border = '2px solid #00fff7';
        closeBtn.style.borderRadius = '50px';
        closeBtn.style.margin = '32px 0 0 0';
        closeBtn.style.cursor = 'pointer';
        closeBtn.onclick = () => {
            modal.remove();
            URL.revokeObjectURL(url);
        };
        modal.appendChild(closeBtn);
    }, 'image/png');
}

function showScoreCardModal({ score = 0, level = 1, accuracy = null, onSubmit = null }) {
    // Remove any existing modal
    let modal = document.getElementById('scoreCardModal');
    if (modal) modal.remove();
    // Create modal
    modal = document.createElement('div');
    modal.id = 'scoreCardModal';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100vw';
    modal.style.height = '100vh';
    modal.style.background = 'rgba(0,0,0,0.85)';
    modal.style.display = 'flex';
    modal.style.flexDirection = 'column';
    modal.style.justifyContent = 'center';
    modal.style.alignItems = 'center';
    modal.style.zIndex = '9999';
    document.body.appendChild(modal);
    // Name input
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.maxLength = 10;
    nameInput.placeholder = 'Enter Name';
    nameInput.value = '';
    nameInput.style.fontSize = '28px';
    nameInput.style.textAlign = 'center';
    nameInput.style.margin = '16px 0 12px 0';
    nameInput.style.padding = '8px 16px';
    nameInput.style.borderRadius = '8px';
    nameInput.style.border = '2px solid #00fff7';
    nameInput.style.background = '#222';
    nameInput.style.color = '#ffd700';
    nameInput.style.fontFamily = 'Orbitron, Arial, sans-serif';
    modal.appendChild(nameInput);
    // Image preview
    const img = document.createElement('img');
    img.style.maxWidth = '90vw';
    img.style.maxHeight = '60vh';
    img.style.borderRadius = '18px';
    img.style.boxShadow = '0 0 32px #00fff7, 0 0 8px #ffd700 inset';
    img.style.marginBottom = '24px';
    modal.appendChild(img);
    // Helper to update image
    function updateImage() {
        generateScoreCardImageDataURL({
            name: nameInput.value || 'PLAYER',
            score,
            level,
            accuracy
        }, (dataUrl) => {
            img.src = dataUrl;
        });
    }
    nameInput.addEventListener('input', updateImage);
    updateImage();
    // Social media/share buttons row
    const btnRow = document.createElement('div');
    btnRow.style.display = 'flex';
    btnRow.style.flexDirection = 'row';
    btnRow.style.justifyContent = 'center';
    btnRow.style.gap = '12px';
    btnRow.style.margin = '12px 0 0 0';
    modal.appendChild(btnRow);
    // Helper to get blob for sharing
    function getBlob(cb) {
        generateScoreCardImageBlob({
            name: nameInput.value || 'PLAYER',
            score,
            level,
            accuracy
        }, cb);
    }
    // Social platforms
    const gameUrl = encodeURIComponent('https://yourgameurl.com');
    const shareText = encodeURIComponent(`Check out my score in Space Clash 2.0! Can you beat me?`);
    const platforms = [
        { id: 'twitter', label: 'Twitter/X', icon: '🐦', url: `https://twitter.com/intent/tweet?text=${shareText}%20${gameUrl}` },
        { id: 'facebook', label: 'Facebook', icon: '📘', url: `https://www.facebook.com/sharer/sharer.php?u=${gameUrl}&quote=${shareText}` },
        { id: 'reddit', label: 'Reddit', icon: '👽', url: `https://www.reddit.com/submit?title=Space%20Clash%202.0%20High%20Score!&text=${shareText}%20${gameUrl}` },
        { id: 'whatsapp', label: 'WhatsApp', icon: '💬', url: `https://api.whatsapp.com/send?text=${shareText}%20${gameUrl}` }
    ];
    platforms.forEach(platform => {
        const btn = document.createElement('button');
        btn.textContent = platform.icon + ' ' + platform.label;
        btn.style.padding = '10px 18px';
        btn.style.fontSize = '18px';
        btn.style.background = '#00fff7';
        btn.style.color = '#222';
        btn.style.border = 'none';
        btn.style.borderRadius = '50px';
        btn.style.cursor = 'pointer';
        btn.onclick = () => {
            // Save to localStorage (high score)
            if (typeof onSubmit === 'function') {
                onSubmit(nameInput.value || 'PLAYER', score, level, accuracy);
            }
            // Download the image first, then open the share URL
            getBlob(blob => {
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'spaceclash2-score.png';
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                setTimeout(() => {
                    document.body.removeChild(a);
                }, 100);
                // Open the social share URL in a new tab
                window.open(platform.url, '_blank');
            });
        };
        btnRow.appendChild(btn);
    });
    // Download button
    const downloadBtn = document.createElement('button');
    downloadBtn.textContent = 'Download Image';
    downloadBtn.style.padding = '10px 18px';
    downloadBtn.style.fontSize = '18px';
    downloadBtn.style.background = '#ffd700';
    downloadBtn.style.color = '#222';
    downloadBtn.style.border = 'none';
    downloadBtn.style.borderRadius = '50px';
    downloadBtn.style.cursor = 'pointer';
    downloadBtn.style.marginLeft = '12px';
    downloadBtn.onclick = () => {
        getBlob(blob => {
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'spaceclash2-score.png';
            a.click();
        });
    };
    btnRow.appendChild(downloadBtn);
    // Submit button (localStorage only)
    const submitBtn = document.createElement('button');
    submitBtn.textContent = 'Submit High Score';
    submitBtn.style.padding = '10px 18px';
    submitBtn.style.fontSize = '18px';
    submitBtn.style.background = '#00c853';
    submitBtn.style.color = '#fff';
    submitBtn.style.border = 'none';
    submitBtn.style.borderRadius = '50px';
    submitBtn.style.cursor = 'pointer';
    submitBtn.style.marginLeft = '12px';
    submitBtn.onclick = () => {
        if (typeof onSubmit === 'function') {
            onSubmit(nameInput.value || 'PLAYER', score, level, accuracy);
        }
        modal.remove();
    };
    btnRow.appendChild(submitBtn);
    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.textContent = 'Close';
    closeBtn.style.padding = '10px 28px';
    closeBtn.style.fontSize = '18px';
    closeBtn.style.background = '#222';
    closeBtn.style.color = '#fff';
    closeBtn.style.border = '2px solid #00fff7';
    closeBtn.style.borderRadius = '50px';
    closeBtn.style.margin = '32px 0 0 0';
    closeBtn.style.cursor = 'pointer';
    closeBtn.onclick = () => {
        modal.remove();
    };
    modal.appendChild(closeBtn);
}

// Helper: generate image as data URL
function generateScoreCardImageDataURL(opts, cb) {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 340;
    const ctx = canvas.getContext('2d');
    drawScoreCard(ctx, opts);
    cb(canvas.toDataURL('image/png'));
}
// Helper: generate image as blob
function generateScoreCardImageBlob(opts, cb) {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 340;
    const ctx = canvas.getContext('2d');
    drawScoreCard(ctx, opts);
    canvas.toBlob(cb, 'image/png');
}
// Helper: draw the score card
function drawScoreCard(ctx, { name = 'PLAYER', score = 0, level = 1, accuracy = null }) {
    ctx.fillStyle = '#1b2735';
    ctx.fillRect(0, 0, 600, 340);
    ctx.strokeStyle = '#00fff7';
    ctx.lineWidth = 8;
    ctx.shadowColor = '#00fff7';
    ctx.shadowBlur = 16;
    ctx.strokeRect(8, 8, 600 - 16, 340 - 16);
    ctx.shadowBlur = 0;
    ctx.font = 'bold 38px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText('Space Clash 2.0', 600 / 2, 32);
    ctx.font = 'bold 28px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#ffd700';
    ctx.fillText(name, 600 / 2, 90);
    ctx.font = 'bold 54px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#00fff7';
    ctx.fillText(`Score: ${score}`, 600 / 2, 150);
    ctx.font = 'bold 32px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#ff00ff';
    ctx.fillText(`Level: ${level}`, 600 / 2, 220);
    if (accuracy !== null && !isNaN(accuracy)) {
        ctx.font = 'bold 28px Orbitron, Arial, sans-serif';
        ctx.fillStyle = '#ffd700';
        ctx.fillText(`Accuracy: ${Math.round(accuracy)}%`, 600 / 2, 255);
    }
    ctx.font = '20px Orbitron, Arial, sans-serif';
    ctx.fillStyle = '#fff';
    ctx.fillText('Can you beat my score?', 600 / 2, 280);
}

// Usage example (uncomment to test):
// generateScoreCardImage({ name: 'PLAYER', score: 12345, level: 7 }); 