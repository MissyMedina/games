// Dynamic difficulty adjustment system
export class DifficultyManager {
    constructor() {
        // Base values
        this.BASE_SPEED = 1;
        this.MIN_SPEED = 0.8;  // Minimum speed for struggling players
        this.MAX_SPEED = 2.5;  // Maximum speed cap for very skilled players
        this.SPEED_INCREMENT = 0.1;  // Gradual speed increase
        this.SPEED_DECREMENT = 0.05;  // Slower speed decrease
        
        // Scoring multipliers
        this.SPEED_MULTIPLIER = 1.2;  // Score multiplier for higher speeds
        
        // Current state
        this.currentSpeed = this.BASE_SPEED;
        this.speedLevel = 0;  // Track speed level for scoring
        this.consecutiveHits = 0;  // Track consecutive hits
        this.lastAdjustmentTime = Date.now();
        this.adjustmentCooldown = 5000;  // Minimum time between adjustments (5 seconds)
    }

    // Adjust difficulty based on player metrics
    adjustDifficulty(metrics) {
        const now = Date.now();
        if (now - this.lastAdjustmentTime < this.adjustmentCooldown) {
            return null;  // Don't adjust too frequently
        }

        const engagementIndex = metrics.getEngagementIndex();
        const accuracy = metrics.accuracy.hits / metrics.accuracy.shots || 0;
        
        // Track consecutive hits for speed boosts
        if (accuracy > 0.7) {  // High accuracy threshold
            this.consecutiveHits++;
        } else {
            this.consecutiveHits = Math.max(0, this.consecutiveHits - 1);
        }

        // Calculate new speed based on performance
        let newSpeed = this.currentSpeed;
        
        if (engagementIndex > 0.7) {  // Player is doing well
            if (this.consecutiveHits >= 3) {  // Reward consistent good performance
                newSpeed = Math.min(this.currentSpeed + this.SPEED_INCREMENT, this.MAX_SPEED);
                this.speedLevel++;
            }
        } else if (engagementIndex < 0.3) {  // Player is struggling
            newSpeed = Math.max(this.currentSpeed - this.SPEED_DECREMENT, this.MIN_SPEED);
            this.speedLevel = Math.max(0, this.speedLevel - 1);
        }

        // Update current speed if changed
        if (newSpeed !== this.currentSpeed) {
            this.currentSpeed = newSpeed;
            this.lastAdjustmentTime = now;
        }

        return null;  // No wave pattern changes
    }

    // Get current score multiplier based on speed level
    getScoreMultiplier() {
        return 1 + (this.speedLevel * 0.1);  // 10% increase per speed level
    }

    // Reset difficulty to base values
    reset() {
        this.currentSpeed = this.BASE_SPEED;
        this.speedLevel = 0;
        this.consecutiveHits = 0;
        this.lastAdjustmentTime = Date.now();
    }
} 